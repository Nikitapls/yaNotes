//
//  ViewController.swift
//  NotesList
//
//  Created by ios_school on 2/19/20.
//  Copyright © 2020 ios_school. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

